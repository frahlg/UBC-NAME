# boot.py -- run on boot-up
